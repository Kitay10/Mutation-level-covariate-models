## this is the gLDA version of SEM_init_params_JMCSM_NEW
## see SEM_init_params_JMCSM_NEW for further documentation

import numpy as np
import math
from copy import deepcopy
from f_get_exposures import get_exposures


def SEM_init_params_bLDA_NEW(counted_train_set, BRCA_Signatures):
    
    mu = 0
    sigma = 3
    MMM_Exposures_num_of_Iters = 100
    M = 96 # number of mutations
    K = len(BRCA_Signatures)
    DATA = deepcopy(counted_train_set)
    T = len(DATA) # number of samples
    a_LDA_tag = np.random.normal(mu, sigma, K)
    a_LDA = []
    for k in range(0, K):
        a_LDA.insert(len(a_LDA),math.exp(a_LDA_tag[k]))
    
    a_LDA = np.array(a_LDA)
    a_LDA = np.reshape(a_LDA, [K, 1])
    
    gamma = []
    for sig in BRCA_Signatures:
        gamma.insert(len(gamma),sig[1:])
        
    gamma_ar = np.zeros((K,M))
    for k in range(0, K):
        for m in range(0,M):
            gamma_ar[k][m] = float(gamma[k][m])
    
    gamma_ar_mk = np.reshape(np.transpose(gamma_ar),(M,K,1))
    
    e = np.array(get_exposures(DATA, MMM_Exposures_num_of_Iters))
    e = e.reshape([T,K,1])
    
    return [mu, sigma, M, K, DATA, T, e, a_LDA, gamma_ar_mk]

    