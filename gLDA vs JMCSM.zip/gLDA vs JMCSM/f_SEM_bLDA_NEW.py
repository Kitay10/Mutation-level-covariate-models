## this is the gLDA version of SEM_JMCSM_NEW
## see SEM_JMCSM_NEW for further documentation

def SEM_bLDA_NEW(counted_train_set, BRCA_Signatures, C, D):

    from f_SEM_init_params_bLDA_NEW import SEM_init_params_bLDA_NEW
    from f_Gibbs_Sampler_N_bLDA_NEW import Gibbs_Sampler_N_bLDA_NEW
    from f_Initial_assignment_guess_LDA import Initial_assignment_guess_LDA
    from f_Update_a_bLDA_NEW import Update_a_bLDA_NEW
    from f_tk_from_tkm_array import tk_from_tkm_array
    import numpy as np
    
    [mu, sigma, M, K, DATA, T, e, a_LDA, gamma_ar_mk] = SEM_init_params_bLDA_NEW(counted_train_set, BRCA_Signatures)
    [N_t_array, N_tk_array, N_tkm_array] = Initial_assignment_guess_LDA(T, M, K, DATA)
        
    a_LDA_history = [a_LDA]
    
    for d in range(0, D):
        print(d)
        [N_t_array, N_tk_array, N_tkm_array] = Initial_assignment_guess_LDA(T, M, K, DATA)
        N_tkm_array_new = Gibbs_Sampler_N_bLDA_NEW(N_t_array, N_tk_array, N_tkm_array, K, T, C, e, a_LDA, gamma_ar_mk)
        N_tk_array_new = tk_from_tkm_array(N_tkm_array_new, N_t_array, T, K)
        a_LDA_new = Update_a_bLDA_NEW(N_t_array, N_tk_array_new, e, a_LDA, T, K, sigma)
        a_LDA = np.copy(a_LDA_new)
        a_LDA_history.insert(len(a_LDA_history), a_LDA)
        # N_tk_array = np.copy(N_tk_array_new)
        # N_tkm_array = np.copy(N_tkm_array_new)

        
    return [e, a_LDA , a_LDA_history]