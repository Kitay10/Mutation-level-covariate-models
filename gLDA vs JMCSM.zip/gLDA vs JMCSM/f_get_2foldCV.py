# This function is used to import the data and split it into
# train and test sets, for the 2-fold cross validation

from f_Import_Signatures import Import_Signatures
from f_Create_Mutation_Dictionary import Create_Mutation_Dictionary
from f_Organize_Data_In_Samples import Organize_Data_In_Samples
from f_Count_Mutations_In_Samples import Count_Mutations_In_Samples

def get_2foldCV(Mutation_Data):
    from copy import deepcopy
    [Mutation_Types, BRCA_Signatures] =  Import_Signatures()
    Mutation_Dictionary = Create_Mutation_Dictionary(Mutation_Types)
    data = deepcopy(Mutation_Data)
    data_organized_in_samples = Organize_Data_In_Samples(data, Mutation_Dictionary)
    set1 = []
    set2 = []
    ## this loops split divide every sample into two sets
    ## and create the train and test sets
    for sample in data_organized_in_samples:
        samp = sample[1]
        set1_temp = []
        set2_temp = []
        for ind in range(0,len(samp)):
            if (ind % 2) == 0:
                set1_temp.insert(len(set1_temp), samp[ind])
            else:
                set2_temp.insert(len(set2_temp), samp[ind])
        set1.insert(len(set1), [sample[0],set1_temp])
        set2.insert(len(set2), [sample[0],set2_temp])
    ## counts the number of times each mutation category occurs in each sample 
    counted_set1 = Count_Mutations_In_Samples(set1)
    counted_set2 = Count_Mutations_In_Samples(set2)

    return [counted_set1, counted_set2]
