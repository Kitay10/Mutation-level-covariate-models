# this function organzie the imported data into a nested list with the following hierarchy:
# [mutation category + feature] in [chromoosme] in [sample]

def Organize_Data_In_Samples(data, Mutation_Dictionary):
    organized_data = []
    for sample in data:
        sample_name = sample[0]
        current_sample = []
        for chro in sample[1]:
            chromosome_number = chro[0]
            for mut in chro[1]:
                mut_number = Mutation_Dictionary[mut[0]]
                mut_features = mut[1]
                temp_mut = [sample_name, chromosome_number, mut_number, mut_features]
                current_sample.insert(len(current_sample),temp_mut)
        organized_data.insert(len(organized_data),[sample_name,current_sample])
    return organized_data