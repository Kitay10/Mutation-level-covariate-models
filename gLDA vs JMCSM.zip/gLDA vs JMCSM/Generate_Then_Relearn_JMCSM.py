from f_Import_Signatures import Import_Signatures 
from f_get_2foldCV import get_2foldCV 
from f_Import_Mutation_Data_LEADLAGG import Import_Mutation_Data_LEADLAGG 
from f_SEM_JMCSM_NEW import SEM_JMCSM_NEW 
from f_SEM_bLDA_NEW import SEM_bLDA_NEW 
from f_JMCSM_NEW_EL import JMCSM_NEW_EL
from f_bLDA_NEW_EL import bLDA_NEW_EL
import numpy as np
from f_SEM_init_params_JMCSM_NEW import SEM_init_params_JMCSM_NEW
import math


D = 50
C = 3000 
S = 100 
G = 1000
a_CV = [] 
b_CV = [] 
a_history_CV = []

ll_JMCSM_history_list = []
ll_bLDA_history_list = []


[Mutation_Types, BRCA_Signatures] =  Import_Signatures()
K = len(BRCA_Signatures) # number of signatures

# import real data
# we use this to generate data with the same number of mutations per sample
Mutation_Data = Import_Mutation_Data_LEADLAGG()

data_2fold_CV = get_2foldCV(Mutation_Data)
[train_set, test_set] = data_2fold_CV

Whole_Data = []
Data_list = []
T = len(data_2fold_CV[0])
for t in range(0,T):
    strnd0 = [x + y for x, y in zip(train_set[t][1], test_set[t][1])]
    strnd1 = [x + y for x, y in zip(train_set[t][2], test_set[t][2])]
    Whole_Data.insert(t, [train_set[t][0],list(strnd0),list(strnd1)])
    
R = 2

a_gen_list = []
b_gen_list = []    
a_est_list = []
b_est_list = []  
a_bLDA_est_list = []

for r in range(0,R):
    # initialize parameters
    [mu, sigma, M, K, DATA, T, e, a_gen, b_gen, gamma_ar_mk] = SEM_init_params_JMCSM_NEW(Whole_Data, BRCA_Signatures)
    mu = 0
    sigma = 1
    a_tag = np.random.normal(mu, sigma, K)
    b_tag = np.random.normal(mu, sigma, K)
    a = []
    b = []
    for k in range(0, K):
        a.insert(len(a),math.exp(a_tag[k]))
        b.insert(len(b),math.exp(b_tag[k]))
    
    a_gen = np.array(a)
    a_gen = np.reshape(a, [K, 1]) * G
    b_gen = np.array(b)
    b_gen = np.reshape(b, [K, 1]) * G
    
    gamma = []
    
    for sig in BRCA_Signatures:
        gamma.insert(len(gamma),sig[1:])
        
    gamma_ar = np.zeros((K,M))
    for k in range(0, K):
        for m in range(0,M):
            gamma_ar[k][m] = float(gamma[k][m])
    
    gamma_ar_mk = np.transpose(gamma_ar)
    
    num_mut = []
    for sample in Whole_Data:
        num_mut.insert(len(num_mut), [sum(sample[1]),sum(sample[2])])
        
    gen_train_set = []
    gen_test_set = []
    name_samp = 'DOXXX'
    #Generate Data
    for t in range(0,T):
        ae = np.multiply(a_gen,e[t])
        be = np.multiply(b_gen,e[t])
        rand_exposure_a = np.random.dirichlet((np.reshape(ae, ae.size)))
        rand_exposure_b = np.random.dirichlet((np.reshape(be, be.size)))
        prob_m_a = np.matmul(gamma_ar_mk,rand_exposure_a)
        prob_m_b = np.matmul(gamma_ar_mk,rand_exposure_b)
        strnd0_muts_train = np.random.multinomial(num_mut[t][0]/2, prob_m_a, size=1)
        strnd0_muts_train = list(strnd0_muts_train[0])
        strnd1_muts_train = np.random.multinomial(num_mut[t][1]/2, prob_m_b, size=1)
        strnd1_muts_train = list(strnd1_muts_train[0])
        strnd0_muts_test = np.random.multinomial(num_mut[t][0]/2, prob_m_a, size=1)
        strnd0_muts_test = list(strnd0_muts_test[0])
        strnd1_muts_test = np.random.multinomial(num_mut[t][1]/2, prob_m_b, size=1)
        strnd1_muts_test = list(strnd1_muts_test[0])
        gen_train_set.insert(t, [name_samp, strnd0_muts_train, strnd1_muts_train])
        gen_test_set.insert(t, [name_samp, strnd0_muts_test, strnd1_muts_test])
    
    Data_list.insert(len(Data_list), [gen_train_set, gen_test_set])
    # learn parameters
    [e_JMCSM, a, b, a_history ,b_history] = SEM_JMCSM_NEW(gen_train_set, BRCA_Signatures, C, D)
    [e_bLDA, a_bLDA, a_bLDA_history] = SEM_bLDA_NEW(gen_train_set, BRCA_Signatures, C, D)

    a_gen_list.insert(len(a_gen_list), a_gen)
    b_gen_list.insert(len(b_gen_list), b_gen)
    a_est_list.insert(len(a_est_list), a)
    b_est_list.insert(len(b_est_list), b)
    a_bLDA_est_list.insert(len(a_bLDA_est_list), a_bLDA)
    
    ll_JMCSM_history = []
    ll_bLDA_history = []
    
    # calculate likelihoods
    for d in range(0,D):
        a_d = a_history[d]
        b_d = b_history[d]
        a_bLDA_d = a_bLDA_history[d]
        ll_JMCSM = JMCSM_NEW_EL(BRCA_Signatures, e_JMCSM, a_d, b_d, gen_test_set, S)
        ll_bLDA = bLDA_NEW_EL(BRCA_Signatures, e_bLDA, a_bLDA_d, gen_test_set, S) 
        ll_JMCSM_history.insert(len(ll_JMCSM_history), ll_JMCSM)
        ll_bLDA_history.insert(len(ll_bLDA_history), ll_bLDA)
        ll_diff = ll_JMCSM - ll_bLDA
        print(ll_diff)
    
    ll_JMCSM_history_list.insert(len(ll_JMCSM_history_list), ll_JMCSM_history)
    ll_bLDA_history_list.insert(len(ll_bLDA_history_list), ll_bLDA_history)
