## this function execute Gibbs sampling for mutations with a specific strand feature for JMCSM
## in order to draw signature assignments for each mutation
## the output is an array that counts number of mutations category and assignments for every sample
## it is almost identical to Gibbs_Sampler_I_MCSM. however, here we use equation (5) and not its variation

import numpy as np
import numba

@numba.njit
def Gibbs_Sampler_I_JMCSM_NEW(I_t_array, I_tk_array, I_tkm_array, K, T, C, e, a, gamma_ar_mk):
        
    A = np.sum(a)
    
    I_t_array_new = np.copy(I_t_array)
    I_tk_array_new = np.copy(I_tk_array)
    I_tkm_array_new = np.copy(I_tkm_array)
        
    for t in range(0,T): # do for each sample seperately        

        I_t = I_t_array_new[t]
        I_tk = I_tk_array_new[t]
        I_tkm = I_tkm_array_new[t]
        denominator_I = I_t - 1 + np.sum(np.multiply(a,e[t]))
        for c in range(0,C): # number of gibbs iterations
            for i in range(0, I_t):
                current_k = I_tkm[i][1]
                current_m = I_tkm[i][0]
                I_tk[current_k][0] = I_tk[current_k][0] - 1
                numerator = np.add(I_tk, np.multiply(a,e[t]))
                gamma_ar_m = gamma_ar_mk[current_m]
                p_k_given_m_prop = np.multiply(numerator,gamma_ar_m) / denominator_I#
                p_k_given_m_norm = np.sum(p_k_given_m_prop)#
                p_k_given_m = p_k_given_m_prop / p_k_given_m_norm#
                p_k_given_m_CDF = np.cumsum(p_k_given_m)
                rnd_temp = np.random.rand()
                for q in range(0,K):
                    if rnd_temp < p_k_given_m_CDF[q]:
                        new_k = q
                        break  
                    
                I_tkm[i][1] = new_k
                I_tk[new_k] = I_tk[new_k] + 1
    return I_tkm_array_new