## this function is the gLAD version of JMCSM_NEW_EL
## see JMCSM_NEW_EL for further documentation

def bLDA_NEW_EL(BRCA_Signatures, e, a_LDA, counted_test_set, S):
    import numpy as np
    #S - number of exposure samples
    gamma = []
    K = len(BRCA_Signatures)
    M = 96
    for sig in BRCA_Signatures:
        gamma.insert(len(gamma),sig[1:])
        
    gamma_ar = np.zeros((K,M))
    for k in range(0, K):
        for m in range(0,M):
            gamma_ar[k][m] = float(gamma[k][m])
    
    gamma_ar_mk = np.transpose(gamma_ar)
    
    log_likelihood_a_LDA = 0
    log_likelihood_b_LDA = 0

    for t in range(0,len(counted_test_set)):
                
        sample = counted_test_set[t]
        ae = np.multiply(a_LDA,e[t])
        be = np.multiply(a_LDA,e[t])
        
        for s in range(0, S):
            rand_exposure_a_LDA = np.random.dirichlet((np.reshape(ae, ae.size)))
            rand_exposure_b_LDA = np.random.dirichlet((np.reshape(be, be.size)))
            prob_m_a_LDA = np.matmul(gamma_ar_mk,rand_exposure_a_LDA)
            prob_m_b_LDA = np.matmul(gamma_ar_mk,rand_exposure_b_LDA)
            log_likelihood_a_LDA = log_likelihood_a_LDA + np.sum(np.multiply(np.log(prob_m_a_LDA),np.array(sample[1])))
            log_likelihood_b_LDA = log_likelihood_b_LDA + np.sum(np.multiply(np.log(prob_m_b_LDA),np.array(sample[2])))
    
    log_likelihood_LDA = log_likelihood_a_LDA + log_likelihood_b_LDA
    
    log_likelihood_LDA = log_likelihood_LDA / S
        
    return log_likelihood_LDA