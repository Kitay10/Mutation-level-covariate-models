from f_Import_Signatures import Import_Signatures 
from f_get_2foldCV import get_2foldCV 
from f_Import_Mutation_Data_LEADLAGG import Import_Mutation_Data_LEADLAGG 
import numpy as np
from f_SEM_MCSM import SEM_MCSM # stochastic EM for MCSM
from f_SEM_init_params_MCSM import SEM_init_params_MCSM
from f_SEM_LDA import SEM_LDA # stochastic EM for LDA
from f_MCSM_EL import MCSM_EL # calculate empirical likelihood for MCSM
from f_LDA_EL import LDA_EL# calculate empirical likelihood for LDA

D = 50
C = 3000 
S = 10000
a_CV = [] 
b_CV = [] 
a_history_CV = []

ll_MCSM_history_list = []
ll_LDA_history_list = []

a_MCSM_history_list = [] 
b_MCSM_history_list = [] 
a_LDA_history_list = []

[Mutation_Types, BRCA_Signatures] =  Import_Signatures()
K = len(BRCA_Signatures) # number of signatures

# import real data
# we use this to generate data with the same number of mutations per sample
Mutation_Data = Import_Mutation_Data_LEADLAGG()

data_2fold_CV = get_2foldCV(Mutation_Data)
[train_set, test_set] = data_2fold_CV

Whole_Data = []
Data_list = []

T = len(data_2fold_CV[0])
for t in range(0,T):
    strnd0 = [x + y for x, y in zip(train_set[t][1], test_set[t][1])]
    strnd1 = [x + y for x, y in zip(train_set[t][2], test_set[t][2])]
    Whole_Data.insert(t, [train_set[t][0],list(strnd0),list(strnd1)])

R = 2 

a_gen_list = []
b_gen_list = []    
a_est_list = []
b_est_list = []    
a_LDA_est_list = []

for r in range(0,R):
    
    # initialize parameters
    [mu, sigma, M, K, DATA, T, a_gen, b_gen, gamma_ar_mk] = SEM_init_params_MCSM(Whole_Data, BRCA_Signatures)
    
    mu = 0
    sigma = 1
    
    gamma = []
    
    for sig in BRCA_Signatures:
        gamma.insert(len(gamma),sig[1:])
        
    gamma_ar = np.zeros((K,M))
    for k in range(0, K):
        for m in range(0,M):
            gamma_ar[k][m] = float(gamma[k][m])
    
    gamma_ar_mk = np.transpose(gamma_ar)
    
    num_mut = []
    for sample in Whole_Data:
        num_mut.insert(len(num_mut), [sum(sample[1]),sum(sample[2])])
        
    gen_train_set = []
    gen_test_set = []
    
    #Generate Data
    name_samp = 'DOXXX'
    for t in range(0,T):
    
        rand_exposure_a = np.random.dirichlet((np.reshape(a_gen, a_gen.size)))
        rand_exposure_b = np.random.dirichlet((np.reshape(b_gen, b_gen.size)))
        prob_m_a = np.matmul(gamma_ar_mk,rand_exposure_a)
        prob_m_b = np.matmul(gamma_ar_mk,rand_exposure_b)
        strnd0_muts_train = np.random.multinomial(num_mut[t][0]/2, prob_m_a, size=1)
        strnd0_muts_train = list(strnd0_muts_train[0])
        strnd1_muts_train = np.random.multinomial(num_mut[t][1]/2, prob_m_b, size=1)
        strnd1_muts_train = list(strnd1_muts_train[0])
        strnd0_muts_test = np.random.multinomial(num_mut[t][0]/2, prob_m_a, size=1)
        strnd0_muts_test = list(strnd0_muts_test[0])
        strnd1_muts_test = np.random.multinomial(num_mut[t][1]/2, prob_m_b, size=1)
        strnd1_muts_test = list(strnd1_muts_test[0])
        gen_train_set.insert(t, [name_samp, strnd0_muts_train, strnd1_muts_train])
        gen_test_set.insert(t, [name_samp, strnd0_muts_test, strnd1_muts_test])

    Data_list.insert(len(Data_list), [gen_train_set, gen_test_set])
    # learn parameters
    [a, b, a_history ,b_history] = SEM_MCSM(gen_train_set, BRCA_Signatures, C, D)
    [a_LDA, a_LDA_history] = SEM_LDA(gen_train_set, BRCA_Signatures, C, D)

    a_MCSM_history_list.insert(len(a_MCSM_history_list), a_history) 
    b_MCSM_history_list.insert(len(b_MCSM_history_list), b_history) 
    a_LDA_history_list.insert(len(a_LDA_history_list), a_LDA_history) 

    a_gen_list.insert(len(a_gen_list), a_gen)
    b_gen_list.insert(len(b_gen_list), b_gen)
    a_est_list.insert(len(a_est_list), a)
    b_est_list.insert(len(b_est_list), b)
    a_LDA_est_list.insert(len(a_LDA_est_list), a_LDA)

    ll_MCSM_history = []
    ll_LDA_history = []
    
    # calculate likelihoods
    for d in range(0,D):
        a_d = a_history[d]
        b_d = b_history[d]
        a_LDA_d = a_LDA_history[d]
        ll_MCSM = MCSM_EL(BRCA_Signatures, a_d, b_d, gen_test_set, S)
        ll_LDA = LDA_EL(BRCA_Signatures, a_LDA_d, gen_test_set, S)
        ll_MCSM_history.insert(len(ll_MCSM_history), ll_MCSM)
        ll_LDA_history.insert(len(ll_LDA_history), ll_LDA)
        ll_diff = ll_MCSM - ll_LDA
        print(ll_diff)

    
    ll_MCSM_history_list.insert(len(ll_MCSM_history_list), ll_MCSM_history)
    ll_LDA_history_list.insert(len(ll_LDA_history_list), ll_LDA_history)