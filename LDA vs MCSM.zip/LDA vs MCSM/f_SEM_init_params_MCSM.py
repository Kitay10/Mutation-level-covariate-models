## this function initializes parameters for the MCSM stochastic EM algorithm
##

import numpy as np
import math
from copy import deepcopy

def SEM_init_params_MCSM(counted_train_set, BRCA_Signatures):
    
    mu = 0 # used to draw random values for a' and b'
    sigma = 1 # # used to draw random values for a' and b'
    M = 96 # number of mutations
    K = len(BRCA_Signatures) # number of signatures
    DATA = deepcopy(counted_train_set)
    T = len(DATA) # number of samples
    a_tag = np.random.normal(mu, sigma, K) # random draw of a'
    b_tag = np.random.normal(mu, sigma, K) # random draw of b'
    a = []
    b = []
    for k in range(0, K):
        a.insert(len(a),math.exp(a_tag[k]))
        b.insert(len(b),math.exp(b_tag[k]))
    
    a = np.array(a)
    a = np.reshape(a, [K, 1])
    b = np.array(b)
    b = np.reshape(b, [K, 1])
    
    #############################################
    ## translate signatures from string to floats
    gamma = []
    for sig in BRCA_Signatures:
        gamma.insert(len(gamma),sig[1:])
        
    gamma_ar = np.zeros((K,M))
    for k in range(0, K):
        for m in range(0,M):
            gamma_ar[k][m] = float(gamma[k][m])
    #############################################

    gamma_ar_mk = np.reshape(np.transpose(gamma_ar),(M,K,1))
    
    return [mu, sigma, M, K, DATA, T, a, b, gamma_ar_mk]

    