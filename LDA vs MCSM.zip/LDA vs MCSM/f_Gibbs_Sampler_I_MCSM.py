## this function execute Gibbs sampling for mutations with a specific strand feature
## in order to draw signature assignments for each mutation
## the output is an array that counts number of mutations category and assignments for every sample

## note that in the paper, we only provide the gibbs sampling equation for JMCSM (equation 5)
## here, we use slightly different version of it, given in reference [27] Hanna M Wallach, Iain Murray, Ruslan Salakhutdinov, and David
## Mimno. Evaluation methods for topic models. In Proceedings of the
## 26th annual international conference on machine learning, pages 1105–1112, 2009.

import numpy as np
import numba

@numba.njit
def Gibbs_Sampler_I_MCSM(I_t_array, I_tk_array, I_tkm_array, K, T, C, a, gamma_ar_mk):
        
    A = np.sum(a)
    
    I_t_array_new = np.copy(I_t_array)
    I_tk_array_new = np.copy(I_tk_array)
    I_tkm_array_new = np.copy(I_tkm_array)
        
    for t in range(0,T): # do for each sample seperately        

        I_t = I_t_array_new[t] # number of mutations per sample
        I_tk = I_tk_array_new[t] ## number of times each signature is assigned per sample
        I_tkm = I_tkm_array_new[t] ## note that a change in I_tkm changes I_tkm_array_new
        denominator_I = I_t - 1 + A ## see equation (5) variation - see rows comment 5-8 
        for c in range(0,C): # number of gibbs iterations
            for i in range(0, I_t): # run over every muation in the sample
                current_k = I_tkm[i][1] # current assignment
                current_m = I_tkm[i][0] # current mutation category
                I_tk[current_k][0] = I_tk[current_k][0] - 1 # take out current mutation
                numerator = np.add(I_tk, a) ## see equation (5) variation - see rows comment 5-8 
                gamma_ar_m = gamma_ar_mk[current_m] ## prob for current mutation given assignment
                p_k_given_m_prop = np.multiply(numerator,gamma_ar_m) / denominator_I# ## see equation (5) variation - see rows comment 5-8 
                p_k_given_m_norm = np.sum(p_k_given_m_prop)# 
                p_k_given_m = p_k_given_m_prop / p_k_given_m_norm#
                ############## draw assignment
                p_k_given_m_CDF = np.cumsum(p_k_given_m)
                rnd_temp = np.random.rand()
                for q in range(0,K):
                    if rnd_temp < p_k_given_m_CDF[q]:
                        new_k = q
                        break  
                
                ## update assignment count
                I_tkm[i][1] = new_k
                I_tk[new_k] = I_tk[new_k] + 1
    return I_tkm_array_new