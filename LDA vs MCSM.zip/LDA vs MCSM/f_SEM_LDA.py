## this function execute the stochastic EM (SEM) algorithm for LDA
## its inputs are the train set, the signatures, the number of gibbs sampling iterations and number of SEM iterations
## the output is an estimation for a and its estimation history
## see SEM_MCSM for further documentation

def SEM_LDA(counted_train_set, BRCA_Signatures, C, D):

    from f_SEM_init_params_LDA import SEM_init_params_LDA
    from f_Gibbs_Sampler_N_LDA import Gibbs_Sampler_N_LDA
    from f_Initial_assignment_guess_LDA import Initial_assignment_guess_LDA
    from f_Update_a_LDA import Update_a_LDA
    from f_tk_from_tkm_array import tk_from_tkm_array
    import numpy as np
    
    [mu, sigma, M, K, DATA, T, a_LDA, gamma_ar_mk] = SEM_init_params_LDA(counted_train_set, BRCA_Signatures)
    [N_t_array, N_tk_array, N_tkm_array] = Initial_assignment_guess_LDA(T, M, K, DATA)
    
    a_LDA_history = [a_LDA]

    for d in range(0, D):
        print(d)
        [N_t_array, N_tk_array, N_tkm_array] = Initial_assignment_guess_LDA(T, M, K, DATA)
        N_tkm_array_new = Gibbs_Sampler_N_LDA(N_t_array, N_tk_array, N_tkm_array, K, T, C, a_LDA, gamma_ar_mk)
        N_tk_array_new = tk_from_tkm_array(N_tkm_array_new, N_t_array, T, K)
        a_LDA_new = Update_a_LDA(N_t_array, N_tk_array_new, a_LDA, T, K, sigma)
        a_LDA = np.copy(a_LDA_new)
        a_LDA_history.insert(len(a_LDA_history), a_LDA)
        # N_tk_array = np.copy(N_tk_array_new)
        # N_tkm_array = np.copy(N_tkm_array_new)

        
    return [a_LDA , a_LDA_history]